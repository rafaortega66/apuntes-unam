#! /usr/bin/env python3
# -*- coding: utf-8 -*-
# ## #############################################################
#
# Práctica 6 / 6b — Experimento 1 [6 pt]
# "Modifique el código de la subsección 4.4 para que la Raspberry Pi
#  imprima en pantalla los valores de temperatura leídos."
#
# Es el programa del Paso 4 + impresión en pantalla de cada lectura
# (hora legible, temperatura, bytes crudos recibidos) sin dejar de
# guardar la bitácora.
#
# Uso:   python3 exp1_imprime_temperatura.py
#        python3 exp1_imprime_temperatura.py --sim   (sin hardware)
# ## ############################################################
import struct
import sys
import time
from datetime import datetime

SLAVE_ADDR = 0x0A
LOG_FILE   = './temp.log'
SIMULATE   = '--sim' in sys.argv

if not SIMULATE:
    import smbus2
    i2c = smbus2.SMBus(1)


def readTemperature():
    '''Regresa (temperatura, bytes_crudos) o (None, None) si falla'''
    if SIMULATE:
        import math, random
        t = 24 + 3 * math.sin(time.time() / 60) + random.uniform(-0.3, 0.3)
        return t, list(struct.pack('<f', t))
    try:
        msg = smbus2.i2c_msg.read(SLAVE_ADDR, 4)
        i2c.i2c_rdwr(msg)
        data = list(msg)
        temp = struct.unpack('<f', bytearray(data))[0]
        if not -55.0 <= temp <= 150.0:
            return None, data
        return temp, data
    except OSError as e:
        print('  [!] Error de I2C:', e)
        return None, None


def log_temp(temperature):
    if temperature is None:
        return
    with open(LOG_FILE, 'a') as fp:
        fp.write('{:.3f} {:.2f}°C\n'.format(time.time(), temperature))


def main():
    print('Leyendo temperatura del esclavo I2C 0x{:02X} cada segundo'.format(SLAVE_ADDR))
    print('Bitácora: {}   (Ctrl+C para salir)'.format(LOG_FILE))
    print('-' * 62)
    print('{:<21} {:>10}   {}'.format('Fecha y hora', 'Temp', 'Bytes recibidos'))
    print('-' * 62)
    while True:
        try:
            temp, raw = readTemperature()
            hora = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            if temp is None:
                print('{:<21} {:>10}   {}'.format(hora, '---', raw))
            else:
                print('{:<21} {:>8.2f}°C   {}'.format(hora, temp, raw))
                log_temp(temp)
            time.sleep(1)
        except KeyboardInterrupt:
            print('\nFin.')
            return


if __name__ == '__main__':
    main()
