#! /usr/bin/env python3
# -*- coding: utf-8 -*-
# ## #############################################################
#
# Práctica 6 / 6b — Paso 4 (Subsección 4.4): bitácora de temperatura vía I2C
# (sirve igual para el Arduino y para la Pico: ambos están en 0x0A)
#
# Basado en raspberry-code-i2c.py (M. Matamoros). Correcciones:
#  1. El log se abría con 'w+' -> se BORRABA en cada lectura y sólo quedaba
#     una línea. Ahora se abre con 'a' (append).
#  2. struct.unpack() regresa una TUPLA (25.3,), no un float -> se toma [0].
#  3. Si la lectura falla (None) o es absurda (fuera de -55..150 °C) no se
#     escribe en la bitácora.
#  4. Faltaba proteger el caso de error de I2C (se reporta en pantalla).
#
# Uso:   python3 raspberry-code-i2c.py          (Ctrl+C para salir)
#        python3 raspberry-code-i2c.py --sim    (sin hardware, datos simulados)
# ## ############################################################
import struct
import sys
import time

SLAVE_ADDR = 0x0A          # Dirección I2C del Arduino / Pico
LOG_FILE   = './temp.log'  # Bitácora: "<timestamp UNIX> <temp>°C"
SIMULATE   = '--sim' in sys.argv

if not SIMULATE:
    import smbus2
    # Raspberry Pi 2/3/4/5 usan el bus 1 (la RPi 1 usaba el bus 0)
    i2c = smbus2.SMBus(1)


def readTemperature():
    '''Pide 4 bytes al esclavo y los convierte a float (little-endian)'''
    if SIMULATE:
        import math, random
        return 24 + 3 * math.sin(time.time() / 60) + random.uniform(-0.3, 0.3)
    try:
        msg = smbus2.i2c_msg.read(SLAVE_ADDR, 4)
        i2c.i2c_rdwr(msg)              # Ejecuta la transacción de lectura
        ba = bytearray(list(msg))      # 4 bytes recibidos
        temp = struct.unpack('<f', ba)[0]
        if not -55.0 <= temp <= 150.0:
            print('Lectura fuera de rango: {} -> {}'.format(list(ba), temp))
            return None
        return temp
    except OSError as e:
        print('Error de I2C:', e)
        return None


def log_temp(temperature):
    '''Agrega una línea a la bitácora'''
    if temperature is None:
        return
    try:
        with open(LOG_FILE, 'a') as fp:
            fp.write('{:.3f} {:.2f}°C\n'.format(time.time(), temperature))
    except OSError as e:
        print('No se pudo escribir la bitácora:', e)


def main():
    while True:
        try:
            cTemp = readTemperature()
            log_temp(cTemp)
            time.sleep(1)
        except KeyboardInterrupt:
            return


if __name__ == '__main__':
    main()
