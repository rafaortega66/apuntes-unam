#! /usr/bin/env python3
# -*- coding: utf-8 -*-
# ## #############################################################
#
# Práctica 6 / 6b — Experimento 3 [+5 pt, adicional]
# "Modifique el código de la subsección 4.4 para que la Raspberry Pi sirva
#  una página web donde se pueda observar la gráfica de temperatura
#  (histórico) desde la bitácora con resolución de hasta 1 minuto."
#
# - Hilo 1: lee el sensor por I2C cada segundo y lo agrega a temp.log
#           (el mismo programa del Paso 4).
# - Hilo 2: servidor HTTP (sólo biblioteca estándar, nada que instalar).
#   La página LEE LA BITÁCORA, agrupa las lecturas por MINUTO (promedio,
#   mínimo y máximo de cada minuto) y dibuja la gráfica en SVG.
#   Se recarga sola cada 60 s. Rango seleccionable: 15 min, 1 h, 6 h, 24 h, todo.
#   También expone /api/datos?min=60 con el JSON por minuto.
#
# Uso:   python3 exp3_servidor_web.py              -> http://<IP-de-la-Pi>:8080
#        python3 exp3_servidor_web.py --sim        (sin hardware)
#        python3 exp3_servidor_web.py --port 9000
# Para ver la IP de la Pi:  hostname -I
# ## ############################################################
import json
import struct
import sys
import threading
import time
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs

SLAVE_ADDR = 0x0A
LOG_FILE   = './temp.log'
SIMULATE   = '--sim' in sys.argv
PORT       = int(sys.argv[sys.argv.index('--port') + 1]) if '--port' in sys.argv else 8080

i2c = None
if not SIMULATE:
    import smbus2
    i2c = smbus2.SMBus(1)

log_lock = threading.Lock()


# ===================== Paso 4: lectura + bitácora =====================
def readTemperature():
    if SIMULATE:
        import math, random
        return 24 + 3 * math.sin(time.time() / 600) + random.uniform(-0.3, 0.3)
    try:
        msg = smbus2.i2c_msg.read(SLAVE_ADDR, 4)
        i2c.i2c_rdwr(msg)
        temp = struct.unpack('<f', bytearray(list(msg)))[0]
        return temp if -55.0 <= temp <= 150.0 else None
    except OSError:
        return None


def log_temp(temperature):
    if temperature is None:
        return
    with log_lock, open(LOG_FILE, 'a') as fp:
        fp.write('{:.3f} {:.2f}°C\n'.format(time.time(), temperature))


def logger():
    while True:
        t = readTemperature()
        log_temp(t)
        if t is not None:
            print('{}  {:.2f} °C'.format(datetime.now().strftime('%H:%M:%S'), t))
        time.sleep(1)


# ===================== Lectura de bitácora por minuto =====================
def datos_por_minuto(minutos=None):
    '''Lee temp.log y agrupa por minuto.
       Regresa lista de dicts {t, prom, min, max, n} ordenada por tiempo.'''
    desde = time.time() - minutos * 60 if minutos else 0
    grupos = {}
    with log_lock:
        try:
            fp = open(LOG_FILE, encoding='utf-8')
        except FileNotFoundError:
            return []
        with fp:
            for line in fp:
                parts = line.split()
                if len(parts) < 2:
                    continue
                try:
                    ts = float(parts[0])
                    t = float(parts[1].replace('°C', '').replace('C', ''))
                except ValueError:
                    continue
                if ts < desde:
                    continue
                m = int(ts // 60) * 60           # inicio del minuto
                g = grupos.setdefault(m, [0.0, 0, t, t])
                g[0] += t
                g[1] += 1
                g[2] = min(g[2], t)
                g[3] = max(g[3], t)
    return [{'t': m, 'prom': round(s / n, 2), 'min': mn, 'max': mx, 'n': n}
            for m, (s, n, mn, mx) in sorted(grupos.items())]


# ===================== Gráfica SVG =====================
def svg_grafica(datos, ancho=900, alto=380):
    if not datos:
        return ('<p class="vacio">Aún no hay datos en la bitácora. '
                'Espera un minuto y recarga.</p>')
    ml, mr, mt, mb = 55, 15, 15, 45
    w, h = ancho - ml - mr, alto - mt - mb
    t0, t1 = datos[0]['t'], datos[-1]['t']
    if t1 == t0:
        t1 = t0 + 60
    ymin = min(d['min'] for d in datos)
    ymax = max(d['max'] for d in datos)
    pad = max(0.5, (ymax - ymin) * 0.1)
    ymin, ymax = ymin - pad, ymax + pad

    def X(t): return ml + (t - t0) / (t1 - t0) * w
    def Y(v): return mt + (ymax - v) / (ymax - ymin) * h

    p = ['<svg viewBox="0 0 {} {}" role="img" aria-label="Temperatura por minuto">'
         .format(ancho, alto)]
    # rejilla y eje Y
    for i in range(6):
        v = ymin + (ymax - ymin) * i / 5
        y = Y(v)
        p.append('<line x1="{}" x2="{}" y1="{:.1f}" y2="{:.1f}" class="grid"/>'
                 .format(ml, ml + w, y, y))
        p.append('<text x="{}" y="{:.1f}" class="lbl" text-anchor="end">{:.1f}</text>'
                 .format(ml - 6, y + 4, v))
    # eje X (6 marcas de hora)
    for i in range(6):
        t = t0 + (t1 - t0) * i / 5
        x = X(t)
        p.append('<text x="{:.1f}" y="{}" class="lbl" text-anchor="middle">{}</text>'
                 .format(x, mt + h + 18, datetime.fromtimestamp(t).strftime('%H:%M')))
    p.append('<text x="14" y="{}" class="lbl" transform="rotate(-90 14 {})" '
             'text-anchor="middle">°C</text>'.format(mt + h / 2, mt + h / 2))
    # banda min-max
    banda = ['{:.1f},{:.1f}'.format(X(d['t']), Y(d['max'])) for d in datos] + \
            ['{:.1f},{:.1f}'.format(X(d['t']), Y(d['min'])) for d in reversed(datos)]
    p.append('<polygon points="{}" class="banda"/>'.format(' '.join(banda)))
    # línea del promedio por minuto
    linea = ' '.join('{:.1f},{:.1f}'.format(X(d['t']), Y(d['prom'])) for d in datos)
    p.append('<polyline points="{}" class="linea"/>'.format(linea))
    # puntos con tooltip (uno por minuto)
    if len(datos) <= 400:
        for d in datos:
            p.append('<circle cx="{:.1f}" cy="{:.1f}" r="2.5" class="pt"><title>{} — '
                     'prom {:.2f} °C (min {:.2f}, max {:.2f}, {} lecturas)</title></circle>'
                     .format(X(d['t']), Y(d['prom']),
                             datetime.fromtimestamp(d['t']).strftime('%d/%m %H:%M'),
                             d['prom'], d['min'], d['max'], d['n']))
    p.append('</svg>')
    return '\n'.join(p)


PAGINA = '''<!doctype html>
<html lang="es"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="refresh" content="60">
<title>Bitácora de temperatura</title>
<style>
 body{{font-family:system-ui,sans-serif;margin:0;padding:16px;background:#f6f7f9;color:#1d232b}}
 .card{{max-width:960px;margin:0 auto;background:#fff;border-radius:10px;padding:18px;
        box-shadow:0 1px 4px rgba(0,0,0,.08)}}
 h1{{font-size:1.3rem;margin:0 0 4px}} .sub{{color:#5b6573;font-size:.9rem;margin:0 0 14px}}
 .actual{{font-size:2.4rem;font-weight:700;color:#c0392b}}
 nav a{{display:inline-block;margin:0 6px 10px 0;padding:5px 11px;border-radius:6px;
        background:#eef1f5;color:#1d232b;text-decoration:none;font-size:.9rem}}
 nav a.on{{background:#1d232b;color:#fff}}
 svg{{width:100%;height:auto}} .grid{{stroke:#e3e7ec}} .lbl{{font-size:11px;fill:#5b6573}}
 .linea{{fill:none;stroke:#c0392b;stroke-width:2}} .banda{{fill:#c0392b;opacity:.15}}
 .pt{{fill:#c0392b}} table{{border-collapse:collapse;font-size:.85rem;margin-top:12px}}
 td,th{{padding:3px 10px;border-bottom:1px solid #eee;text-align:right}}
 .vacio{{padding:40px;text-align:center;color:#5b6573}}
</style></head><body><div class="card">
<h1>Bitácora de temperatura — LM35 vía I²C (0x{addr:02X})</h1>
<p class="sub">Resolución: 1 minuto (promedio; la banda clara es mín–máx del minuto).
 Se actualiza cada 60 s. Generado {ahora}.</p>
<div class="actual">{actual}</div>
<nav>{nav}</nav>
{svg}
<table><tr><th>Minuto</th><th>Prom °C</th><th>Mín</th><th>Máx</th><th>Lecturas</th></tr>
{filas}</table>
</div></body></html>'''


class Handler(BaseHTTPRequestHandler):
    RANGOS = [(15, '15 min'), (60, '1 h'), (360, '6 h'), (1440, '24 h'), (0, 'Todo')]

    def do_GET(self):
        url = urlparse(self.path)
        q = parse_qs(url.query)
        try:
            minutos = int(q.get('min', ['60'])[0])
        except ValueError:
            minutos = 60

        if url.path == '/api/datos':
            cuerpo = json.dumps(datos_por_minuto(minutos or None)).encode()
            return self._enviar(cuerpo, 'application/json')
        if url.path != '/':
            self.send_error(404)
            return

        datos = datos_por_minuto(minutos or None)
        actual = '{:.2f} °C'.format(datos[-1]['prom']) if datos else '— °C'
        nav = ''.join('<a href="/?min={}" class="{}">{}</a>'.format(
            m, 'on' if m == minutos else '', etiqueta) for m, etiqueta in self.RANGOS)
        filas = ''.join('<tr><td>{}</td><td>{:.2f}</td><td>{:.2f}</td><td>{:.2f}</td>'
                        '<td>{}</td></tr>'.format(
                            datetime.fromtimestamp(d['t']).strftime('%d/%m %H:%M'),
                            d['prom'], d['min'], d['max'], d['n'])
                        for d in reversed(datos[-10:]))
        html = PAGINA.format(addr=SLAVE_ADDR, ahora=datetime.now().strftime('%H:%M:%S'),
                             actual=actual, nav=nav, svg=svg_grafica(datos), filas=filas)
        self._enviar(html.encode('utf-8'), 'text/html; charset=utf-8')

    def _enviar(self, cuerpo, tipo):
        self.send_response(200)
        self.send_header('Content-Type', tipo)
        self.send_header('Content-Length', str(len(cuerpo)))
        self.end_headers()
        self.wfile.write(cuerpo)

    def log_message(self, *args):
        pass   # no ensuciar la terminal con cada petición


def main():
    threading.Thread(target=logger, daemon=True).start()
    srv = ThreadingHTTPServer(('0.0.0.0', PORT), Handler)
    print('Servidor en http://0.0.0.0:{}  (abre http://<IP de la Pi>:{})'.format(PORT, PORT))
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print('\nFin.')


if __name__ == '__main__':
    main()
