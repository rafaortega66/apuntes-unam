#! /usr/bin/env python3
# -*- coding: utf-8 -*-
# ## #############################################################
#
# Práctica 6 / 6b — Experimento 2 [4 pt]
# "Modifique el código de la subsección 4.4 para que la Raspberry Pi
#  grafique el histórico de temperaturas registradas, leyendo los valores
#  almacenados e ingresados en la bitácora."
#
# Un hilo sigue leyendo el sensor por I2C y escribiendo temp.log (igual que
# el Paso 4), mientras la ventana de matplotlib RE-LEE la bitácora cada 2 s
# y redibuja la gráfica completa. Al cerrar, guarda grafica_temperatura.png.
#
# Requisitos:  sudo apt install python3-matplotlib
# Uso:
#   python3 exp2_grafica_bitacora.py             (lee I2C + grafica en vivo)
#   python3 exp2_grafica_bitacora.py --solo-log  (sólo grafica temp.log)
#   python3 exp2_grafica_bitacora.py --png       (sin ventana, sólo genera PNG;
#                                                 útil por SSH sin escritorio)
#   Agrega --sim para probar sin hardware.
# ## ############################################################
import struct
import sys
import threading
import time
from datetime import datetime

import matplotlib
if '--png' in sys.argv:
    matplotlib.use('Agg')          # sin pantalla
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from matplotlib.animation import FuncAnimation

SLAVE_ADDR = 0x0A
LOG_FILE   = './temp.log'
PNG_FILE   = './grafica_temperatura.png'
SIMULATE   = '--sim' in sys.argv
SOLO_LOG   = '--solo-log' in sys.argv or '--png' in sys.argv

i2c = None
if not SIMULATE and not SOLO_LOG:
    import smbus2
    i2c = smbus2.SMBus(1)


# ---------- Parte del Paso 4: lectura I2C + bitácora ----------
def readTemperature():
    if SIMULATE:
        import math, random
        return 24 + 3 * math.sin(time.time() / 60) + random.uniform(-0.3, 0.3)
    try:
        msg = smbus2.i2c_msg.read(SLAVE_ADDR, 4)
        i2c.i2c_rdwr(msg)
        temp = struct.unpack('<f', bytearray(list(msg)))[0]
        return temp if -55.0 <= temp <= 150.0 else None
    except OSError:
        return None


def log_temp(temperature):
    if temperature is None:
        return
    with open(LOG_FILE, 'a') as fp:
        fp.write('{:.3f} {:.2f}°C\n'.format(time.time(), temperature))


def logger(stop_event):
    while not stop_event.is_set():
        t = readTemperature()
        log_temp(t)
        if t is not None:
            print('{}  {:.2f} °C'.format(datetime.now().strftime('%H:%M:%S'), t))
        stop_event.wait(1)


# ---------- Lectura de la bitácora ----------
def read_log(path=LOG_FILE):
    '''Regresa dos listas: fechas (datetime) y temperaturas (float)'''
    fechas, temps = [], []
    try:
        with open(path, encoding='utf-8') as fp:
            for line in fp:
                parts = line.split()
                if len(parts) < 2:
                    continue
                try:
                    ts = float(parts[0])
                    t = float(parts[1].replace('°C', '').replace('C', ''))
                except ValueError:
                    continue            # línea corrupta (p. ej. "None")
                fechas.append(datetime.fromtimestamp(ts))
                temps.append(t)
    except FileNotFoundError:
        pass
    # ordenar por tiempo (por si la bitácora se juntó de varias corridas)
    pares = sorted(zip(fechas, temps))
    return [p[0] for p in pares], [p[1] for p in pares]


# ---------- Gráfica ----------
fig, ax = plt.subplots(figsize=(10, 5))


def dibujar(_frame=None):
    fechas, temps = read_log()
    ax.clear()
    ax.set_title('Histórico de temperatura (LM35) — {}'.format(LOG_FILE))
    ax.set_xlabel('Hora')
    ax.set_ylabel('Temperatura [°C]')
    ax.grid(True, alpha=0.3)
    if fechas:
        ax.plot(fechas, temps, '-', linewidth=1.2, color='tab:red')
        ax.xaxis.set_major_formatter(mdates.DateFormatter('%H:%M:%S'))
        ax.text(0.01, 0.97,
                'n={}  min={:.2f}  max={:.2f}  última={:.2f} °C'.format(
                    len(temps), min(temps), max(temps), temps[-1]),
                transform=ax.transAxes, va='top', fontsize=9)
    else:
        ax.text(0.5, 0.5, 'La bitácora está vacía', ha='center',
                transform=ax.transAxes)
    fig.autofmt_xdate()


def main():
    stop = threading.Event()
    if not SOLO_LOG:
        threading.Thread(target=logger, args=(stop,), daemon=True).start()

    if '--png' in sys.argv:
        dibujar()
        fig.savefig(PNG_FILE, dpi=120, bbox_inches='tight')
        print('Gráfica guardada en', PNG_FILE)
        return

    anim = FuncAnimation(fig, dibujar, interval=2000, cache_frame_data=False)
    try:
        plt.show()
    finally:
        stop.set()
        dibujar()
        fig.savefig(PNG_FILE, dpi=120, bbox_inches='tight')
        print('Gráfica guardada en', PNG_FILE)
    del anim


if __name__ == '__main__':
    main()
