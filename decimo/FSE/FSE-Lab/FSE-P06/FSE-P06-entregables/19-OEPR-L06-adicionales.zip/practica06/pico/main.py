# ## #############################################################
#
# Práctica 6b — Paso 4 (Subsección 4.4): Pico como esclavo I2C (0x0A)
# Guardar en la Pico con el nombre  main.py  (junto con i2cslave.py)
#
# Basado en src/pico-code-i2c.py (M. Matamoros). Correcciones:
#  1. Faltaba 'import machine' (setup() usaba machine.ADC).
#  2. read_temp() era un "dummy" que regresaba siempre 25.0; ahora lee el
#     LM35 de verdad (con la escala correcta de read_u16: 0..65535).
#  3. Se promedian varias lecturas para reducir ruido.
#
# Conexiones I2C (Tabla 2 de la 6b):
#   Raspberry pin 3 (GPIO2/SDA) -> Pico pin 1 (GP0 / I2C0 SDA)
#   Raspberry pin 5 (GPIO3/SCL) -> Pico pin 2 (GP1 / I2C0 SCL)
#   Raspberry pin 6 (GND)       -> Pico pin 3 (GND)
# ## ############################################################
import machine
import ustruct
from utime import sleep_ms
from i2cslave import I2CSlave

VREF           = 3.330    # <-- voltaje MEDIDO entre ADC_VREF (35) y AGND (33)
I2C_SLAVE_ADDR = 0x0A

i2c = None
adcm = None
adcp = None


def setup():
    global i2c, adcm, adcp
    i2c  = I2CSlave(address=I2C_SLAVE_ADDR)   # I2C0: SDA=GP0, SCL=GP1
    adcm = machine.ADC(0)                     # GP26 -> Vout-
    adcp = machine.ADC(1)                     # GP27 -> Vout+
# end def


def read_temp():
    '''Temperatura en °C: vdiff * VREF / (65536 * 0.01)'''
    vdiff = adcp.read_u16() - adcm.read_u16()
    return vdiff * VREF / 655.36
# end def


def read_avg_temp(count=8):
    s = 0
    for _ in range(count):
        s += read_temp()
    return s / count
# end def


def main():
    setup()
    print('Esclavo I2C listo en 0x{:02X}'.format(I2C_SLAVE_ADDR))
    while True:
        # 1. Medir temperatura
        temperature = read_avg_temp()
        # 2. Convertir el float de Python a 4 bytes (little-endian)
        data = ustruct.pack('<f', temperature)

        # 3. ¿El maestro pidió datos? -> enviarle los 4 bytes
        if i2c.waitForRdReq(timeout=0):
            i2c.write(data)

        # 4. ¿El maestro mandó datos? -> imprimirlos
        if i2c.waitForData(timeout=0):
            rcv = i2c.read()
            try:
                print(rcv.decode('utf-8'))
            except Exception:
                print(rcv)
# end def


if __name__ == '__main__':
    main()
