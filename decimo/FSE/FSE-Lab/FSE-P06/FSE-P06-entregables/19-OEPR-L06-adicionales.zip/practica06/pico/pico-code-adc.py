# ## #############################################################
#
# Práctica 6b — Paso 2 (Subsección 4.2): lectura del LM35 con la Pico
#
# Basado en src/pico-code-adc.py (M. Matamoros). Correcciones:
#  1. 'from machine import ADC' pero se usaba 'machine.ADC' -> NameError.
#  2. setup() creaba adcm/adcp como variables LOCALES y nunca se llamaba.
#  3. read_temp() no tenía 'return' -> devolvía None y el promedio fallaba.
#  4. read_u16() devuelve 0..65535 (el valor de 12 bits escalado a 16 bits),
#     NO 0..4095. Por eso se divide entre 655.36 en lugar de 40.96:
#        T = vdiff * VREF / (65536 * 0.01 V/°C) = vdiff * VREF / 655.36
#
# Conexiones:
#   ADC0 = GP26 = pin físico 31  <- Vout-  (pin 3 del LM35)
#   ADC1 = GP27 = pin físico 32  <- Vout+  (pin 2 del LM35)
#   ADC_VREF = pin 35, AGND = pin 33
#
# Ábrelo con Thonny y dale Run (F5); verás la temperatura en la consola.
# ## ############################################################
import machine
from utime import sleep_ms

# Voltaje MEDIDO con multímetro entre ADC_VREF (pin 35) y AGND (pin 33).
# OJO: en la Pico, ADC_VREF viene unido de fábrica a 3V3 por una resistencia
# pequeña, así que es normal medir ~3.2-3.3 V aunque pongas el divisor 10k/12k.
# Pon aquí lo que mida tu multímetro.
VREF = 3.330 

adcm = None
adcp = None


def setup():
    '''Inicializa los dos canales del ADC'''
    global adcm, adcp
    adcm = machine.ADC(0)   # GP26 -> Vout-
    adcp = machine.ADC(1)   # GP27 -> Vout+
# end def


def read_temp():
    '''Lee la temperatura en °C a partir del ADC'''
    vplus  = adcp.read_u16()      # temperatura
    vminus = adcm.read_u16()      # referencia (0 °C)
    vdiff  = vplus - vminus       # negativo si T < 0 °C
    return vdiff * VREF / 655.36
# end def


def read_avg_temp(count=10):
    '''Promedio de N lecturas'''
    avgtemp = 0
    for i in range(count):
        avgtemp += read_temp()
    return avgtemp / count
# end def


def main():
    setup()
    while True:
        temp = read_avg_temp(20)
        vp = adcp.read_u16() * VREF / 65535
        vm = adcm.read_u16() * VREF / 65535
        print('V+={:.3f} V  V-={:.3f} V  Temp: {:.2f} °C'.format(vp, vm, temp))
        sleep_ms(1000)
# end def


if __name__ == '__main__':
    main()
