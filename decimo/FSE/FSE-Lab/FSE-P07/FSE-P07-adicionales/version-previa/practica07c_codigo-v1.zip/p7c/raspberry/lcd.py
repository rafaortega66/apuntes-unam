# lcd.py — LCD 16x2 por I2C, con el algoritmo de la sección 2.3 de la guía 7c.
# La única diferencia con el PCF8574 es la dirección: la Pico responde en 0x0A.
import struct
import time
import smbus2

LCD_ADDR = 0x0A
BLEN = 1                       # luz de fondo (bit 3); la Pico lo ignora
BUS = smbus2.SMBus(1)


def send_word(addr, data):     # tal cual la guía
    temp = data
    if BLEN == 1:
        temp |= 0x08
    else:
        temp &= 0xF7
    BUS.write_byte(addr, temp)


def _send(value, rs):
    for nibble in (value & 0xF0, (value & 0x0F) << 4):
        buf = nibble | 0x04 | rs           # E = 1, RW = 0
        send_word(LCD_ADDR, buf)
        time.sleep(0.002)
        buf &= 0xFB                        # E = 0
        send_word(LCD_ADDR, buf)


def send_command(cmd):  _send(cmd, 0)      # Algoritmo 1 (RS = 0)
def send_data(data):    _send(data, 1)     # Algoritmo 2 (RS = 1)


def init():                                # Algoritmo 3
    for cmd in (0x33, 0x32, 0x28, 0x0C, 0x01):
        send_command(cmd)
        time.sleep(0.005)


def clear():
    send_command(0x01)
    time.sleep(0.005)


def write(x, y, text):
    """Escribe text desde la columna x de la línea y (0 o 1)."""
    x = max(0, min(15, x)); y = max(0, min(1, y))
    send_command(0x80 + 0x40 * y + x)
    for ch in text[:16 - x]:
        send_data(ord(ch) if ord(ch) < 128 else ord('?'))


def read_temp():
    """Temperatura del LM35 que mide la Pico (float de 4 bytes)."""
    try:
        msg = smbus2.i2c_msg.read(LCD_ADDR, 4)
        BUS.i2c_rdwr(msg)
        return struct.unpack('<f', bytes(list(msg)))[0]
    except OSError:
        return None
