#!/usr/bin/env python3
# Experimento 2 [6 pts]: apellido paterno en la primera línea del display
import lcd

lcd.init()
lcd.write(0, 0, 'LUNA')
