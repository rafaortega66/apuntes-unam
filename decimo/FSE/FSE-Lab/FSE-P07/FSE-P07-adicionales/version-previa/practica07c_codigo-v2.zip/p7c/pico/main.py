# main.py (Pico W) — Práctica 7c: LM35 + Pico como adaptador PCF8574 del LCD
# Guardar en la Pico junto con i2cslave.py.
#
# Esclavo I2C en 0x0A (SDA = GP0, SCL = GP1):
#   - Cada byte que escribe la Raspberry se trata como el puerto del PCF8574:
#       bit 0 = RS -> GP2   bit 2 = E -> GP3   bits 4..7 = D4..D7 -> GP4..GP7
#       (bit 1 = RW y bit 3 = luz de fondo se ignoran: RW va a GND y la luz siempre está encendida)
#   - Una lectura de 4 bytes regresa la temperatura del LM35 (float little-endian).
import machine
import ustruct
from utime import ticks_ms, ticks_diff
from i2cslave import I2CSlave

VREF = 3.330                       # voltaje medido en ADC_VREF (pin 35) en la 6b
adcm = machine.ADC(0)              # GP26 <- Vout- (pata 3 del LM35)
adcp = machine.ADC(1)              # GP27 <- Vout+ (pata 2 del LM35)

RS = machine.Pin(2, machine.Pin.OUT, value=0)
EN = machine.Pin(3, machine.Pin.OUT, value=0)
DATA = [machine.Pin(n, machine.Pin.OUT, value=0) for n in (4, 5, 6, 7)]   # D4..D7


def put_port(b):
    """Pone en los pines lo que el PCF8574 pondría en P0..P7.
    Datos y RS primero; E al final, para que el LCD capture en su flanco de bajada."""
    RS.value(b & 0x01)
    for i, p in enumerate(DATA):
        p.value((b >> (4 + i)) & 1)
    EN.value((b >> 2) & 1)


def read_temp(n=16):
    s = 0
    for _ in range(n):
        s += adcp.read_u16() - adcm.read_u16()
    return (s / n) * VREF / 655.36   # read_u16 va de 0 a 65535 -> 65536 * 0.01 V/°C


def main():
    i2c = I2CSlave(address=0x0A)
    temp = read_temp()
    t_last = ticks_ms()
    print('Pico lista en 0x0A (LCD + LM35)')
    while True:
        # 1. Bytes para el LCD: procesar cada uno en orden
        if i2c.waitForData(timeout=0):
            for b in i2c.read():
                put_port(b)
        # 2. La Raspberry pidió la temperatura
        if i2c.waitForRdReq(timeout=0):
            i2c.write(ustruct.pack('<f', temp))
        # 3. Actualizar la temperatura cada 250 ms sin frenar el bus
        if ticks_diff(ticks_ms(), t_last) >= 250:
            temp = read_temp()
            t_last = ticks_ms()


main()
