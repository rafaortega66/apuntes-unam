#!/usr/bin/env python3
# Experimento 1 [2 pts]: temperatura en la consola cada segundo
import time
import lcd

while True:
    t = lcd.read_temp()
    print('Sin respuesta de la Pico' if t is None else f'{time.strftime("%H:%M:%S")}  {t:.1f} °C')
    time.sleep(1)
