#!/usr/bin/env python3
# Experimento 6 [+5 pts]: página web para cambiar la velocidad y la dirección de la
# marquesina y elegir si la temperatura se muestra en °C, °F o ambas.
# Abrir http://<IP de la Raspberry>:8080 desde el teléfono o la laptop.
#
# Dos hilos:
#   - el del LCD es el único que usa el bus I2C (marquesina + temperatura);
#   - el del servidor web solo lee y cambia la configuración compartida.
import json
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import lcd

estado = {'velocidad': 350, 'direccion': 'izq', 'escala': 'C',   # configuración
          'linea1': '', 'linea2': '', 'temp': None}              # lo que muestra el LCD
candado = threading.Lock()


def hilo_lcd():
    marq = lcd.Marquesina(' '.join(lcd.APELLIDOS) + '   ')
    lcd.init()
    t_temp = 0
    while True:
        with candado:
            vel, dirc, esc = estado['velocidad'], estado['direccion'], estado['escala']
        l1 = marq.paso(dirc)
        lcd.write(0, 0, l1)
        if time.monotonic() - t_temp >= 1:
            t = lcd.read_temp()
            l2 = lcd.temp_text(t, esc)
            lcd.write(0, 1, l2)
            t_temp = time.monotonic()
            with candado:
                estado['temp'], estado['linea2'] = t, l2
        with candado:
            estado['linea1'] = l1
        time.sleep(vel / 1000)


PAGINA = """<!doctype html><html lang="es"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>LCD · Práctica 7</title><style>
body{font-family:system-ui,sans-serif;max-width:460px;margin:24px auto;padding:0 16px;background:#f3f5f7;color:#16202a}
h1{font-size:1.4rem;margin:0 0 12px}
.lcd{background:#2848c8;border-radius:8px;padding:14px 16px;font:600 1.35rem/1.5 ui-monospace,Consolas,monospace;color:#e8efff;white-space:pre;letter-spacing:.06em;box-shadow:inset 0 0 0 6px #1d2f80;overflow:hidden}
.card{background:#fff;border:1px solid #d6dde3;border-radius:8px;padding:14px 16px;margin-top:14px}
label{font-weight:600;display:block;margin-bottom:8px}
input[type=range]{width:100%}
.grupo{display:flex;gap:8px;flex-wrap:wrap}
.grupo button{flex:1;padding:10px;border:1px solid #b9c3cc;border-radius:6px;background:#fff;font:600 1rem system-ui;cursor:pointer}
.grupo button.on{background:#0e7a6f;color:#fff;border-color:#0e7a6f}
.muted{color:#5a6875;font-size:.9rem}
</style></head><body>
<h1>Marquesina del LCD</h1>
<div class="lcd" id="lcd">                \n                </div>
<div class="card"><label for="vel">Velocidad: <span id="velv"></span> ms por paso</label>
<input id="vel" type="range" min="100" max="1000" step="50">
<p class="muted">Menos milisegundos, más rápido.</p></div>
<div class="card"><label>Dirección</label><div class="grupo" id="dir">
<button data-v="izq">◀ Izquierda</button><button data-v="der">Derecha ▶</button></div></div>
<div class="card"><label>Escala de temperatura</label><div class="grupo" id="esc">
<button data-v="C">°C</button><button data-v="F">°F</button><button data-v="CF">Ambas</button></div></div>
<script>
const $=id=>document.getElementById(id);
function marcar(g,v){document.querySelectorAll('#'+g+' button').forEach(b=>b.classList.toggle('on',b.dataset.v===v));}
async function enviar(cambio){await fetch('/api/config',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(cambio)});}
let tocando=false;
$('vel').oninput=()=>{tocando=true;$('velv').textContent=$('vel').value;};
$('vel').onchange=()=>{enviar({velocidad:+$('vel').value});tocando=false;};
document.querySelectorAll('#dir button').forEach(b=>b.onclick=()=>{marcar('dir',b.dataset.v);enviar({direccion:b.dataset.v});});
document.querySelectorAll('#esc button').forEach(b=>b.onclick=()=>{marcar('esc',b.dataset.v);enviar({escala:b.dataset.v});});
async function actualizar(){
  try{const e=await (await fetch('/api/estado')).json();
    $('lcd').textContent=e.linea1+'\\n'+e.linea2;
    if(!tocando){$('vel').value=e.velocidad;$('velv').textContent=e.velocidad;}
    marcar('dir',e.direccion);marcar('esc',e.escala);}catch(err){}
}
actualizar();setInterval(actualizar,300);
</script></body></html>"""


class Manejador(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _json(self, obj, code=200):
        cuerpo = json.dumps(obj, ensure_ascii=False).encode()
        self.send_response(code)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(cuerpo)))
        self.end_headers()
        self.wfile.write(cuerpo)

    def do_GET(self):
        if self.path == '/api/estado':
            with candado:
                return self._json(dict(estado))
        cuerpo = PAGINA.encode()
        self.send_response(200)
        self.send_header('Content-Type', 'text/html; charset=utf-8')
        self.send_header('Content-Length', str(len(cuerpo)))
        self.end_headers()
        self.wfile.write(cuerpo)

    def do_POST(self):
        if self.path != '/api/config':
            return self._json({'error': 'no existe'}, 404)
        try:
            n = int(self.headers.get('Content-Length', 0))
            cambio = json.loads(self.rfile.read(n))
        except (ValueError, json.JSONDecodeError):
            return self._json({'error': 'JSON inválido'}, 400)
        with candado:
            if 'velocidad' in cambio:
                estado['velocidad'] = max(100, min(1000, int(cambio['velocidad'])))
            if cambio.get('direccion') in ('izq', 'der'):
                estado['direccion'] = cambio['direccion']
            if cambio.get('escala') in ('C', 'F', 'CF'):
                estado['escala'] = cambio['escala']
            return self._json(dict(estado))


if __name__ == '__main__':
    threading.Thread(target=hilo_lcd, daemon=True).start()
    print('Abre http://192.168.1.84:8080  (Ctrl+C para salir)')
    ThreadingHTTPServer(('0.0.0.0', 8080), Manejador).serve_forever()
