#!/usr/bin/env python3
# Experimento 7 [+5 pts]: el programa del punto 3 (apellido + temperatura en el LCD)
# más una página web con la gráfica histórica de la bitácora, con resolución de 1 minuto.
# Abrir http://<IP de la Raspberry>:8080
#
# Cada segundo se lee la temperatura; al cerrar cada minuto se guarda el promedio de
# ese minuto en bitacora.csv ("AAAA-MM-DD HH:MM,temperatura"). El archivo se abre en
# modo 'a', así que el historial se conserva entre ejecuciones.
import json
import os
import threading
import time
from datetime import datetime, timedelta
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import lcd

BITACORA = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'bitacora.csv')
candado = threading.Lock()
actual = {'temp': None}


def hilo_lcd():
    lcd.init()
    lcd.write(0, 0, lcd.APELLIDO)
    minuto = datetime.now().strftime('%Y-%m-%d %H:%M')
    muestras = []
    while True:
        t = lcd.read_temp()
        lcd.write(0, 1, lcd.temp_text(t, 'C'))
        with candado:
            actual['temp'] = t
        ahora = datetime.now().strftime('%Y-%m-%d %H:%M')
        if ahora != minuto:                       # cerró el minuto: guardar el promedio
            if muestras:
                prom = sum(muestras) / len(muestras)
                with candado, open(BITACORA, 'a') as f:
                    f.write(f'{minuto},{prom:.2f}\n')
            minuto, muestras = ahora, []
        if t is not None and -10 < t < 110:       # descarta lecturas absurdas
            muestras.append(t)
        time.sleep(1)


def leer_bitacora(minutos):
    """Puntos de los últimos `minutos` (0 = todo)."""
    desde = datetime.now() - timedelta(minutes=minutos) if minutos else None
    puntos = []
    with candado:
        if not os.path.exists(BITACORA):
            return puntos
        with open(BITACORA) as f:
            for linea in f:
                try:
                    marca, valor = linea.strip().split(',')
                    dt = datetime.strptime(marca, '%Y-%m-%d %H:%M')
                except ValueError:
                    continue
                if desde is None or dt >= desde:
                    puntos.append([marca, float(valor)])
    return puntos


PAGINA = """<!doctype html><html lang="es"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Historial de temperatura</title><style>
body{font-family:system-ui,sans-serif;max-width:900px;margin:24px auto;padding:0 16px;background:#f3f5f7;color:#16202a}
h1{font-size:1.4rem;margin:0}
.top{display:flex;flex-wrap:wrap;gap:12px 24px;align-items:baseline;margin-bottom:12px}
.big{font-size:2.4rem;font-weight:700;font-variant-numeric:tabular-nums}
.muted{color:#5a6875;font-size:.9rem}
.grupo{display:flex;gap:6px;flex-wrap:wrap;margin:10px 0}
.grupo button{padding:8px 12px;border:1px solid #b9c3cc;border-radius:6px;background:#fff;font:600 .95rem system-ui;cursor:pointer}
.grupo button.on{background:#0e7a6f;color:#fff;border-color:#0e7a6f}
.card{background:#fff;border:1px solid #d6dde3;border-radius:8px;padding:12px}
canvas{width:100%;height:340px;display:block}
.stats{display:flex;gap:24px;flex-wrap:wrap;margin-top:10px;font-variant-numeric:tabular-nums}
</style></head><body>
<div class="top"><h1>Temperatura del LM35</h1>
<span class="big" id="now">--.- °C</span><span class="muted" id="info"></span></div>
<div class="grupo" id="rango">
<button data-m="60">Última hora</button><button data-m="360">6 horas</button>
<button data-m="1440">24 horas</button><button data-m="0">Todo</button></div>
<div class="card"><canvas id="c"></canvas>
<div class="stats"><span>Mín: <b id="min">–</b></span><span>Máx: <b id="max">–</b></span>
<span>Promedio: <b id="avg">–</b></span><span>Puntos: <b id="n">0</b></span></div></div>
<p class="muted">Un punto por minuto (promedio de 60 lecturas). La gráfica se actualiza sola cada 30 s.</p>
<script>
const $=id=>document.getElementById(id);
let rango=60, puntos=[];
function marcar(){document.querySelectorAll('#rango button').forEach(b=>b.classList.toggle('on',+b.dataset.m===rango));}
document.querySelectorAll('#rango button').forEach(b=>b.onclick=()=>{rango=+b.dataset.m;marcar();cargar();});
function dibujar(){
  const c=$('c'),dpr=window.devicePixelRatio||1,W=c.clientWidth,H=c.clientHeight;
  c.width=W*dpr;c.height=H*dpr;const g=c.getContext('2d');g.scale(dpr,dpr);g.clearRect(0,0,W,H);
  const L=46,R=12,T=12,B=34,w=W-L-R,h=H-T-B;
  g.font='12px system-ui';g.fillStyle='#5a6875';
  if(puntos.length<2){g.fillText(puntos.length?'Esperando el segundo minuto de datos…':'Sin datos todavía: el primer punto aparece al cerrar el minuto.',L,T+20);return;}
  const ts=puntos.map(p=>new Date(p[0].replace(' ','T')).getTime()),vs=puntos.map(p=>p[1]);
  let lo=Math.min(...vs),hi=Math.max(...vs);if(hi-lo<1){const m=(hi+lo)/2;lo=m-0.5;hi=m+0.5;}
  const pad=(hi-lo)*0.1;lo-=pad;hi+=pad;
  const t0=ts[0],t1=ts[ts.length-1]||t0+1;
  const X=t=>L+(t-t0)/Math.max(1,t1-t0)*w,Y=v=>T+(hi-v)/(hi-lo)*h;
  g.strokeStyle='#e3e8ec';g.lineWidth=1;g.textAlign='right';
  for(let i=0;i<=4;i++){const v=lo+(hi-lo)*i/4,y=Y(v);g.beginPath();g.moveTo(L,y);g.lineTo(W-R,y);g.stroke();g.fillText(v.toFixed(1)+'°',L-6,y+4);}
  g.textAlign='center';
  for(let i=0;i<=4;i++){const t=t0+(t1-t0)*i/4,d=new Date(t);g.textAlign=i===0?'left':(i===4?'right':'center');g.fillText(d.toTimeString().slice(0,5),L+w*i/4,H-12);}
  g.strokeStyle='#0e7a6f';g.lineWidth=2;g.beginPath();
  let ant=null;
  ts.forEach((t,i)=>{const x=X(t),y=Y(vs[i]);if(ant!==null&&t-ant>3*60000){g.moveTo(x,y);}else if(i===0){g.moveTo(x,y);}else{g.lineTo(x,y);}ant=t;});
  g.stroke();
  const xl=X(ts[ts.length-1]),yl=Y(vs[vs.length-1]);g.fillStyle='#0e7a6f';g.beginPath();g.arc(xl,yl,4,0,7);g.fill();
}
async function cargar(){
  try{
    const r=await (await fetch('/api/historial?min='+rango)).json();puntos=r.puntos;
    $('now').textContent=r.actual===null?'--.- °C':r.actual.toFixed(1)+' °C';
    $('info').textContent=puntos.length?'Último registro: '+puntos[puntos.length-1][0]:'';
    if(puntos.length){const v=puntos.map(p=>p[1]);
      $('min').textContent=Math.min(...v).toFixed(1)+' °C';$('max').textContent=Math.max(...v).toFixed(1)+' °C';
      $('avg').textContent=(v.reduce((a,b)=>a+b,0)/v.length).toFixed(1)+' °C';}
    $('n').textContent=puntos.length;dibujar();
  }catch(e){}
}
async function actual(){try{const r=await (await fetch('/api/actual')).json();
  $('now').textContent=r.actual===null?'--.- °C':r.actual.toFixed(1)+' °C';}catch(e){}}
window.onresize=dibujar;marcar();cargar();setInterval(cargar,30000);setInterval(actual,2000);
</script></body></html>"""


class Manejador(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _json(self, obj):
        cuerpo = json.dumps(obj).encode()
        self.send_response(200)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Content-Length', str(len(cuerpo)))
        self.end_headers()
        self.wfile.write(cuerpo)

    def do_GET(self):
        if self.path.startswith('/api/historial'):
            try:
                minutos = int(self.path.split('min=')[1])
            except (IndexError, ValueError):
                minutos = 60
            with candado:
                t = actual['temp']
            return self._json({'puntos': leer_bitacora(minutos), 'actual': t})
        if self.path == '/api/actual':
            with candado:
                return self._json({'actual': actual['temp']})
        cuerpo = PAGINA.encode()
        self.send_response(200)
        self.send_header('Content-Type', 'text/html; charset=utf-8')
        self.send_header('Content-Length', str(len(cuerpo)))
        self.end_headers()
        self.wfile.write(cuerpo)


if __name__ == '__main__':
    threading.Thread(target=hilo_lcd, daemon=True).start()
    print('Bitácora en', BITACORA)
    print('Abre http://192.168.1.84:8080  (Ctrl+C para salir)')
    ThreadingHTTPServer(('0.0.0.0', 8080), Manejador).serve_forever()
