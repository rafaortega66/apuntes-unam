#!/usr/bin/env python3
# Experimento 4 [+2 pts]: apellido en la línea 1 y temperatura en °C y °F en la línea 2
import time
import lcd

lcd.init()
lcd.write(0, 0, lcd.APELLIDO)
while True:
    lcd.write(0, 1, lcd.temp_text(lcd.read_temp(), 'CF'))
    time.sleep(1)
