#!/usr/bin/env python3
# Experimento 3 [2 pts]: apellido en la línea 1 y temperatura en la línea 2, cada segundo
import time
import lcd

lcd.init()
lcd.write(0, 0, lcd.APELLIDO)
while True:
    t = lcd.read_temp()
    texto = 'T: --.- C' if t is None else f'T: {t:5.1f} C'
    lcd.write(0, 1, texto.ljust(16))
    time.sleep(1)
