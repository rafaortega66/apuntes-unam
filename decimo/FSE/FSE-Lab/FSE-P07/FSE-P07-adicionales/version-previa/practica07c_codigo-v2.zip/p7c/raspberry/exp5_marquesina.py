#!/usr/bin/env python3
# Experimento 5 [+3 pts]: marquesina izquierda infinita con los apellidos del equipo
# en la línea 1 y la temperatura en la línea 2.
# Un solo ciclo maneja las dos líneas, así nunca hay dos escrituras al LCD a la vez.
import time
import lcd

PASO = 0.35                                   # segundos por posición de la marquesina
marq = lcd.Marquesina(' '.join(lcd.APELLIDOS) + '   ')

lcd.init()
t_temp = 0
while True:
    lcd.write(0, 0, marq.paso('izq'))
    if time.monotonic() - t_temp >= 1:        # temperatura cada segundo
        lcd.write(0, 1, lcd.temp_text(lcd.read_temp(), 'C'))
        t_temp = time.monotonic()
    time.sleep(PASO)
