def _send(value, rs):
    for nibble in (value & 0xF0, (value & 0x0F) << 4):
        buf = nibble | 0x04 | rs           # E = 1, RW = 0
        send_word(LCD_ADDR, buf)
        time.sleep(0.002)
        buf &= 0xFB                        # E = 0
        send_word(LCD_ADDR, buf)

def init():                                # Algoritmo 3
    for cmd in (0x33, 0x32, 0x28, 0x0C, 0x01):
        send_command(cmd)
        time.sleep(0.005)

def write(x, y, text):
    send_command(0x80 + 0x40 * y + x)
    for ch in text[:16 - x]:
        if ch == '°':
            send_data(0xDF)            # símbolo de grado en la ROM del HD44780
        else:
            send_data(ord(ch) if ord(ch) < 128 else ord('?'))
