# Experiments 2 and 3 (exp3_temperatura.py)
lcd.init()
lcd.write(0, 0, lcd.APELLIDO)
while True:
    t = lcd.read_temp()
    texto = 'T: --.- C' if t is None else f'T: {t:5.1f} C'
    lcd.write(0, 1, texto.ljust(16))
    time.sleep(1)
