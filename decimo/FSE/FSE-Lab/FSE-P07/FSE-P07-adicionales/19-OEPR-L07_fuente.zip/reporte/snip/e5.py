# lcd.py, class Marquesina
def paso(self, direccion='izq'):
    n = len(self.texto)
    self.pos = (self.pos + (1 if direccion == 'izq' else -1)) % n
    doble = self.texto * (16 // n + 2)
    return doble[self.pos:self.pos + 16]

# exp5_marquesina.py
while True:
    lcd.write(0, 0, marq.paso('izq'))
    if time.monotonic() - t_temp >= 1:        # temperatura cada segundo
        lcd.write(0, 1, lcd.temp_text(lcd.read_temp(), 'C'))
        t_temp = time.monotonic()
    time.sleep(PASO)
