# lcd.py
def read_temp():
    try:
        msg = smbus2.i2c_msg.read(LCD_ADDR, 4)
        BUS.i2c_rdwr(msg)
        return struct.unpack('<f', bytes(list(msg)))[0]
    except OSError:
        return None

# exp1_consola.py
while True:
    t = lcd.read_temp()
    print('Sin respuesta de la Pico' if t is None else f'{time.strftime("%H:%M:%S")}  {t:.1f} °C')
    time.sleep(1)
