# exp7_web_grafica.py, inside hilo_lcd()
ahora = datetime.now().strftime('%Y-%m-%d %H:%M')
if ahora != minuto:                       # cerró el minuto: guardar el promedio
    if muestras:
        prom = sum(muestras) / len(muestras)
        with candado, open(BITACORA, 'a') as f:
            f.write(f'{minuto},{prom:.2f}\n')
    minuto, muestras = ahora, []
if t is not None and -10 < t < 110:       # descarta lecturas absurdas
    muestras.append(t)
