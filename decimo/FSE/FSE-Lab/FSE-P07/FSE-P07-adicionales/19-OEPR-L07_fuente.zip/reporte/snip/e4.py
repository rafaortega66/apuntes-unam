# lcd.py
def temp_text(t, escala='C'):
    if t is None:
        return 'T: sin lectura'.ljust(16)
    if escala == 'F':
        s = f'T: {c_to_f(t):5.1f}°F'
    elif escala == 'CF':
        s = f'{t:4.1f}°C {c_to_f(t):5.1f}°F'
    else:
        s = f'T: {t:5.1f}°C'
    return s[:16].ljust(16)

# exp4_celsius_fahrenheit.py (inside the loop)
lcd.write(0, 1, lcd.temp_text(lcd.read_temp(), 'CF'))
