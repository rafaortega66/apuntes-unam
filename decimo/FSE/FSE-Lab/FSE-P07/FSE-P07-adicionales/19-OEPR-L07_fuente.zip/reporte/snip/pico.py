# main.py (Pico W)
def put_port(b):
    RS.value(b & 0x01)
    for i, p in enumerate(DATA):
        p.value((b >> (4 + i)) & 1)
    EN.value((b >> 2) & 1)

# main loop
if i2c.waitForData(timeout=0):
    for b in i2c.read():
        put_port(b)
if i2c.waitForRdReq(timeout=0):
    i2c.write(ustruct.pack('<f', temp))
