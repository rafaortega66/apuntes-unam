# exp6_web_marquesina.py, display thread
def hilo_lcd():
    ...
    while True:
        with candado:
            vel, dirc, esc = estado['velocidad'], estado['direccion'], estado['escala']
        l1 = marq.paso(dirc)
        lcd.write(0, 0, l1)
        ...
        time.sleep(vel / 1000)

# web server thread, POST /api/config
with candado:
    if 'velocidad' in cambio:
        estado['velocidad'] = max(100, min(1000, int(cambio['velocidad'])))
    if cambio.get('direccion') in ('izq', 'der'):
        estado['direccion'] = cambio['direccion']
    if cambio.get('escala') in ('C', 'F', 'CF'):
        estado['escala'] = cambio['escala']
