#!/usr/bin/env python3
import os
import time
import glob
import vlc
import pyudev
import subprocess as sp
from gpiozero import Button

HOME = '/home/pi'
VIDEO = HOME + '/videos/video.mp4'
SAMPLE_PICS = sorted(glob.glob(HOME + '/pictures/*.jpg'))
DWELL = 3.0     # segundos por imagen
TOTAL = 20.0    # duracion del video
FADE = 5.0      # subida y bajada de volumen

# --- funciones tomadas de usbdetect.py ---
def auto_mount(path):
    sp.run(["udisksctl", "mount", "-b", path])

def get_mount_point(path):
    cp = sp.run(["findmnt", "-unl", "-S", path], capture_output=True, text=True)
    return cp.stdout.split(" ")[0]

def usb_images(mp):
    return sorted(os.path.join(mp, f) for f in os.listdir(mp)
                  if f.lower().endswith((".jpg", ".png")))

context = pyudev.Context()
monitor = pyudev.Monitor.from_netlink(context)
monitor.filter_by(subsystem="block", device_type="partition")
monitor.start()

player = vlc.MediaPlayer()
items = [VIDEO] + SAMPLE_PICS     # lista de reproduccion
idx = 0
volume = 100                      # volumen maestro (botones)
cmd = None
paused = False
stopped = False
t = 0.0
last = time.monotonic()

# --- botones GPIO (Experimento 4) ---
def push(c):
    global cmd
    cmd = c
    print("BOTON:", c, flush=True)

def cambia_vol(delta):
    global volume
    volume = max(0, min(100, volume + delta))
    print("Volumen maestro:", volume, "%", flush=True)

for gpio, nombre in {2: "prev", 3: "next", 4: "stop", 17: "pause"}.items():
    b = Button(gpio, pull_up=True, bounce_time=0.05)
    b.when_pressed = lambda n=nombre: push(n)
    globals()["btn%d" % gpio] = b

vmas = Button(27, pull_up=True, bounce_time=0.05, hold_time=0.5, hold_repeat=True)
vmas.when_pressed = lambda: cambia_vol(10)
vmas.when_held = lambda: cambia_vol(10)
vmenos = Button(22, pull_up=True, bounce_time=0.05, hold_time=0.5, hold_repeat=True)
vmenos.when_pressed = lambda: cambia_vol(-10)
vmenos.when_held = lambda: cambia_vol(-10)

def fade_factor(x):
    if x < FADE:
        return x / FADE
    if x < TOTAL - FADE:
        return 1.0
    return max(0.0, (TOTAL - x) / FADE)

def show(i):
    global t, last
    is_video = (items[i] == VIDEO)
    if is_video:
        player.audio_set_volume(0)
    player.set_media(vlc.Media(items[i]))
    player.play()
    time.sleep(0.3)
    if is_video:
        player.audio_set_volume(0)
    t = 0.0
    last = time.monotonic()
    print("Mostrando:", items[i], flush=True)

show(idx)
last_print = -1
print("Kiosco listo", flush=True)

while True:
    device = monitor.poll(timeout=0.1)
    now = time.monotonic()
    dt = now - last
    last = now

    if device is not None and device.action == "add":
        dev = "/dev/" + device.sys_name
        auto_mount(dev)
        mp = get_mount_point(dev)
        new = usb_images(mp) if mp else []
        if new:
            items = new
            idx = 0
            paused = stopped = False
            show(idx)
            continue

    c = cmd
    cmd = None
    if c in ("next", "prev"):
        if items[idx] == VIDEO:
            items = SAMPLE_PICS
            idx = 0
        else:
            idx = (idx + (1 if c == "next" else -1)) % len(items)
        paused = stopped = False
        show(idx)
        continue
    elif c == "stop":
        player.stop()
        stopped = True
        paused = False
    elif c == "pause":
        if stopped:
            stopped = False
            show(idx)
            continue
        paused = not paused
        player.set_pause(1 if paused else 0)
        print("PAUSA" if paused else "REANUDA", flush=True)

    if paused or stopped:
        continue

    t += dt
    if items[idx] == VIDEO:
        vol = int(fade_factor(t) * volume)
        player.audio_set_volume(vol)
        if int(t) != last_print:
            last_print = int(t)
            print("t = {:2d} s  volumen = {:3d} %".format(int(t), vol), flush=True)
        if t >= TOTAL or player.get_state() == vlc.State.Ended:
            player.stop()
            items = SAMPLE_PICS
            idx = 0
            show(idx)
    else:
        if t >= DWELL:
            idx = (idx + 1) % len(items)
            show(idx)
