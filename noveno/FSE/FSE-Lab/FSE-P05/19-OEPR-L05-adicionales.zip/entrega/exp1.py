#!/usr/bin/env python3
import vlc
import time
import glob

HOME = '/home/pi'
VIDEO = HOME + '/videos/video.mp4'
PICS = sorted(glob.glob(HOME + '/pictures/*.jpg'))

player = vlc.MediaPlayer()

# 10 segundos de video
player.set_media(vlc.Media(VIDEO))
player.play()
time.sleep(10)
player.stop()

# Bucle infinito de imágenes, 3 s cada una
while True:
    for pic in PICS:
        player.set_media(vlc.Media(pic))
        player.play()
        time.sleep(3)
