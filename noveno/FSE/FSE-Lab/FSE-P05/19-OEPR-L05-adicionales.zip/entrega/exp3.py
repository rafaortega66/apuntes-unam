#!/usr/bin/env python3
import os
import time
import glob
import vlc
import pyudev
import subprocess as sp

HOME = '/home/pi'
VIDEO = HOME + '/videos/video.mp4'
SAMPLE_PICS = sorted(glob.glob(HOME + '/pictures/*.jpg'))

# --- funciones tomadas de usbdetect.py ---
def auto_mount(path):
    sp.run(["udisksctl", "mount", "-b", path])

def get_mount_point(path):
    cp = sp.run(["findmnt", "-unl", "-S", path], capture_output=True, text=True)
    return cp.stdout.split(" ")[0]

def usb_images(mp):
    return sorted(os.path.join(mp, f) for f in os.listdir(mp)
                  if f.lower().endswith((".jpg", ".png")))

context = pyudev.Context()
monitor = pyudev.Monitor.from_netlink(context)
monitor.filter_by(subsystem="block", device_type="partition")
monitor.start()

def wait_for_usb(seconds):
    """Espera 'seconds' s; devuelve el dispositivo si se insertó una USB."""
    end = time.time() + seconds
    while True:
        left = end - time.time()
        if left <= 0:
            return None
        device = monitor.poll(timeout=left)
        if device is not None and device.action == "add":
            return device

def play_video_with_fade(player, path, total=20, fade=5):
    """Video de 'total' s: volumen 0->100 % en 'fade' s, máximo, y 100->0 % al final."""
    player.set_media(vlc.Media(path))
    player.audio_set_volume(0)
    player.play()
    time.sleep(0.5)               # deja que arranque el audio
    player.audio_set_volume(0)
    start = time.time()
    last_print = -1
    while True:
        t = time.time() - start
        if t >= total:
            break
        if t < fade:                  # subida 0 -> 100 %
            vol = t / fade * 100
        elif t < total - fade:        # máximo
            vol = 100
        else:                         # bajada 100 -> 0 %
            vol = (total - t) / fade * 100
        player.audio_set_volume(int(vol))
        if int(t) != last_print:
            last_print = int(t)
            print("t = {:2d} s  volumen = {:3d} %".format(int(t), int(vol)), flush=True)
        time.sleep(0.1)
    player.stop()

player = vlc.MediaPlayer()

# Video de 20 s con subida y bajada de volumen (experimento 3)
play_video_with_fade(player, VIDEO)

# Presentación infinita; cambia a las imágenes de la USB al insertarla
pics = SAMPLE_PICS
while True:
    for pic in pics:
        player.set_media(vlc.Media(pic))
        player.play()
        print("Mostrando:", pic, flush=True)
        device = wait_for_usb(3)
        if device is not None:
            dev = "/dev/" + device.sys_name
            auto_mount(dev)
            mp = get_mount_point(dev)
            new = usb_images(mp) if mp else []
            if new:
                pics = new
            break   # reinicia el for con la lista nueva
