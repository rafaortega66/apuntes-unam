#!/usr/bin/env python3
import os
import time
import glob
import vlc
import pyudev
import subprocess as sp

HOME = '/home/pi'
VIDEO = HOME + '/videos/video.mp4'
SAMPLE_PICS = sorted(glob.glob(HOME + '/pictures/*.jpg'))

# --- funciones tomadas de usbdetect.py ---
def auto_mount(path):
    sp.run(["udisksctl", "mount", "-b", path])

def get_mount_point(path):
    cp = sp.run(["findmnt", "-unl", "-S", path], capture_output=True, text=True)
    return cp.stdout.split(" ")[0]

def usb_images(mp):
    return sorted(os.path.join(mp, f) for f in os.listdir(mp)
                  if f.lower().endswith((".jpg", ".png")))

context = pyudev.Context()
monitor = pyudev.Monitor.from_netlink(context)
monitor.filter_by(subsystem="block", device_type="partition")
monitor.start()

def wait_for_usb(seconds):
    """Espera 'seconds' s; devuelve el dispositivo si se insertó una USB."""
    end = time.time() + seconds
    while True:
        left = end - time.time()
        if left <= 0:
            return None
        device = monitor.poll(timeout=left)
        if device is not None and device.action == "add":
            return device

player = vlc.MediaPlayer()

# 10 s de video (experimento 1)
player.set_media(vlc.Media(VIDEO))
player.play()
time.sleep(10)
player.stop()

# Presentación infinita; cambia a las imágenes de la USB al insertarla
pics = SAMPLE_PICS
while True:
    for pic in pics:
        player.set_media(vlc.Media(pic))
        player.play()
        print("Mostrando:", pic, flush=True)
        device = wait_for_usb(3)
        if device is not None:
            dev = "/dev/" + device.sys_name
            auto_mount(dev)
            mp = get_mount_point(dev)
            new = usb_images(mp) if mp else []
            if new:
                pics = new
            break   # reinicia el for con la lista nueva
